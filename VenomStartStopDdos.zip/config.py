# Don't use quotes( " and ' )
#SCRIPT BY VENOMxCRAZY
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("7255048090:AAFpMpH9KDNrr3BpnlAlraE5c2UkqhlSY5w")

  #Enter Your telegram username here without @
OWNER_USERNAME=("")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("")







  
